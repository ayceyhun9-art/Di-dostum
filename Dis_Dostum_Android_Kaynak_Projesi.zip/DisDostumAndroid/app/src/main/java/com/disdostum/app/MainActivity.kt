package com.disdostum.app

import android.Manifest
import android.app.Activity
import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var morningText: TextView
    private lateinit var eveningText: TextView
    private lateinit var timerText: TextView
    private lateinit var streakText: TextView
    private var timer: CountDownTimer? = null
    private var remaining = 120000L
    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestNotificationPermission()
        buildScreen()
        refreshTimes()
        updateStats()
        AlarmScheduler.scheduleSaved(this)
    }

    private fun buildScreen() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 36, 28, 28)
            setBackgroundColor(0xFFF4FAFF.toInt())
        }
        fun text(value: String, size: Float, color: Int = 0xFF17324D.toInt()): TextView =
            TextView(this).apply { text = value; textSize = size; setTextColor(color); gravity = Gravity.CENTER; setPadding(4, 12, 4, 12) }
        fun button(value: String, action: () -> Unit) = Button(this).apply { text = value; setOnClickListener { action() } }

        layout.addView(text("🦷 Diş Dostum", 30f))
        layout.addView(text("Gülüşünü koru, her gün 2 dakika!", 16f))
        morningText = text("", 18f)
        eveningText = text("", 18f)
        layout.addView(morningText)
        layout.addView(button("Sabah alarmını ayarla") { chooseTime(true) })
        layout.addView(eveningText)
        layout.addView(button("Akşam alarmını ayarla") { chooseTime(false) })
        layout.addView(text("2 dakikalık fırçalama sayacı", 20f))
        timerText = text("02:00", 36f, 0xFF087E8B.toInt())
        layout.addView(timerText)
        layout.addView(button("Sayacı başlat") { startTimer() })
        layout.addView(button("Sayacı sıfırla") { resetTimer() })
        layout.addView(button("Fırçaladım! ✓") { markDone() })
        streakText = text("", 16f)
        layout.addView(streakText)
        layout.addView(text("Hatırlatma: Sabah ve yatmadan önce fırçalamak iyi bir günlük alışkanlıktır.", 14f))
        setContentView(layout)
    }

    private fun chooseTime(isMorning: Boolean) {
        val hKey = if (isMorning) "morningHour" else "eveningHour"
        val mKey = if (isMorning) "morningMinute" else "eveningMinute"
        TimePickerDialog(this, { _, hour, minute ->
            prefs.edit().putInt(hKey, hour).putInt(mKey, minute).apply()
            AlarmScheduler.scheduleDaily(this, hour, minute, if (isMorning) 101 else 202)
            refreshTimes()
            Toast.makeText(this, "Alarm kaydedildi", Toast.LENGTH_SHORT).show()
        }, prefs.getInt(hKey, if (isMorning) 8 else 21), prefs.getInt(mKey, 0), true).show()
    }

    private fun refreshTimes() {
        morningText.text = "🌞 Sabah: %02d:%02d".format(prefs.getInt("morningHour", 8), prefs.getInt("morningMinute", 0))
        eveningText.text = "🌙 Akşam: %02d:%02d".format(prefs.getInt("eveningHour", 21), prefs.getInt("eveningMinute", 0))
    }

    private fun startTimer() {
        timer?.cancel()
        timer = object : CountDownTimer(remaining, 1000) {
            override fun onTick(millis: Long) {
                remaining = millis
                timerText.text = "%02d:%02d".format(millis / 60000, (millis % 60000) / 1000)
            }
            override fun onFinish() {
                remaining = 0
                timerText.text = "Süper! 🎉"
                Toast.makeText(this@MainActivity, "2 dakika tamamlandı!", Toast.LENGTH_LONG).show()
            }
        }.start()
    }

    private fun resetTimer() {
        timer?.cancel()
        remaining = 120000L
        timerText.text = "02:00"
    }

    private fun markDone() {
        val today = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
        val previous = prefs.getString("lastDone", "")
        if (previous != today) {
            val yesterday = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date(System.currentTimeMillis() - 86400000L))
            val streak = if (previous == yesterday) prefs.getInt("streak", 0) + 1 else 1
            prefs.edit().putString("lastDone", today).putInt("streak", streak).apply()
        }
        updateStats()
        Toast.makeText(this, "Harika! Fırçalama kaydedildi 🦷", Toast.LENGTH_SHORT).show()
    }

    private fun updateStats() {
        streakText.text = "🔥 Günlük seri: ${prefs.getInt("streak", 0)} gün"
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val alarmManager = getSystemService(ALARM_SERVICE) as android.app.AlarmManager
            if (!alarmManager.canScheduleExactAlarms()) {
                try { startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))) } catch (_: Exception) {}
            }
        }
    }

    override fun onDestroy() {
        timer?.cancel()
        super.onDestroy()
    }
}
