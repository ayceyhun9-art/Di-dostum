package com.disdostum.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.Calendar

object AlarmScheduler {
    fun scheduleDaily(context: Context, hour: Int, minute: Int, requestCode: Int) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, AlarmReceiver::class.java).putExtra("requestCode", requestCode)
        val pending = PendingIntent.getBroadcast(
            context, requestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val time = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S || alarmManager.canScheduleExactAlarms()) {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, time.timeInMillis, pending)
        } else {
            alarmManager.set(AlarmManager.RTC_WAKEUP, time.timeInMillis, pending)
        }
    }

    fun scheduleSaved(context: Context) {
        val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)
        scheduleDaily(context, prefs.getInt("morningHour", 8), prefs.getInt("morningMinute", 0), 101)
        scheduleDaily(context, prefs.getInt("eveningHour", 21), prefs.getInt("eveningMinute", 0), 202)
    }
}
