package com.disdostum.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import java.util.Calendar

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "tooth_reminders"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "Diş fırçalama hatırlatmaları", NotificationManager.IMPORTANCE_HIGH)
            channel.description = "Sabah ve akşam diş fırçalama alarmı"
            manager.createNotificationChannel(channel)
        }
        val openApp = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Diş Dostum 🦷")
            .setContentText("Dişlerini fırçalama zamanı! 2 dakika ayırmayı unutma.")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(openApp)
            .build()
        manager.notify(intent.getIntExtra("requestCode", 1), notification)

        val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)
        val code = intent.getIntExtra("requestCode", 101)
        val hour = if (code == 101) prefs.getInt("morningHour", 8) else prefs.getInt("eveningHour", 21)
        val minute = if (code == 101) prefs.getInt("morningMinute", 0) else prefs.getInt("eveningMinute", 0)
        AlarmScheduler.scheduleDaily(context, hour, minute, code)
    }
}
