# Diş Dostum – Android başlangıç projesi

Bu klasör, Diş Dostum uygulamasının Android Studio ile derlenebilen Kotlin kaynak projesidir.

## Özellikler
- Sabah ve akşam için günlük hatırlatma alarmı
- Bildirim kanalı ve bildirim sesi (telefonun bildirim ayarlarına bağlı)
- 2 dakikalık geri sayım
- Fırçaladım işaretleme ve günlük seri sayacı
- Telefon yeniden başlatıldığında alarmları yeniden kurma

## APK oluşturma
1. Bilgisayara Android Studio'nun güncel sürümünü kur.
2. Android Studio > Open ile bu klasörü aç.
3. Gradle senkronizasyonunun tamamlanmasını bekle.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) seç.
5. APK, `app/build/outputs/apk/debug/app-debug.apk` konumunda oluşur.

## Önemli
- İlk açılışta bildirim izni verilmeli.
- Android 12 ve üzeri cihazlarda kesin alarm izni istenebilir.
- Üreticiye göre pil optimizasyonu arka plan alarmlarını etkileyebilir.
- Bu bir ilk sürüm kaynak projesidir; farklı Android telefonlarda test edilmeden Play Store'a yayımlanmamalıdır.
- Play Store yayını için geliştirici hesabı, mağaza görselleri, gizlilik politikası ve Google Play'in güncel test/yayın şartları gerekir.
